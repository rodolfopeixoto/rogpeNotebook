 $(document).on('turbolinks:load', function() {
     $('select').material_select();
});
